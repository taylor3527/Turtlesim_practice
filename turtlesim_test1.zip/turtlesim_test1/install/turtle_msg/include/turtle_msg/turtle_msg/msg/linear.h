// generated from rosidl_generator_c/resource/idl.h.em
// with input from turtle_msg:msg/Linear.idl
// generated code does not contain a copyright notice

#ifndef TURTLE_MSG__MSG__LINEAR_H_
#define TURTLE_MSG__MSG__LINEAR_H_

#include "turtle_msg/msg/detail/linear__struct.h"
#include "turtle_msg/msg/detail/linear__functions.h"
#include "turtle_msg/msg/detail/linear__type_support.h"

#endif  // TURTLE_MSG__MSG__LINEAR_H_
