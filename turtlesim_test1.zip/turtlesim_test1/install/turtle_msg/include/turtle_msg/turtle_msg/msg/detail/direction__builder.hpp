// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from turtle_msg:msg/Direction.idl
// generated code does not contain a copyright notice

#ifndef TURTLE_MSG__MSG__DETAIL__DIRECTION__BUILDER_HPP_
#define TURTLE_MSG__MSG__DETAIL__DIRECTION__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "turtle_msg/msg/detail/direction__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace turtle_msg
{

namespace msg
{

namespace builder
{

class Init_Direction_dir
{
public:
  Init_Direction_dir()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::turtle_msg::msg::Direction dir(::turtle_msg::msg::Direction::_dir_type arg)
  {
    msg_.dir = std::move(arg);
    return std::move(msg_);
  }

private:
  ::turtle_msg::msg::Direction msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::turtle_msg::msg::Direction>()
{
  return turtle_msg::msg::builder::Init_Direction_dir();
}

}  // namespace turtle_msg

#endif  // TURTLE_MSG__MSG__DETAIL__DIRECTION__BUILDER_HPP_
