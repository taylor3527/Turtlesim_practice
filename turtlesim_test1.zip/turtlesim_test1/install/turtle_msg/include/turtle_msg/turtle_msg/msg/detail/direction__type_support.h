// generated from rosidl_generator_c/resource/idl__type_support.h.em
// with input from turtle_msg:msg/Direction.idl
// generated code does not contain a copyright notice

#ifndef TURTLE_MSG__MSG__DETAIL__DIRECTION__TYPE_SUPPORT_H_
#define TURTLE_MSG__MSG__DETAIL__DIRECTION__TYPE_SUPPORT_H_

#include "rosidl_typesupport_interface/macros.h"

#include "turtle_msg/msg/rosidl_generator_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_turtle_msg
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  turtle_msg,
  msg,
  Direction
)();

#ifdef __cplusplus
}
#endif

#endif  // TURTLE_MSG__MSG__DETAIL__DIRECTION__TYPE_SUPPORT_H_
