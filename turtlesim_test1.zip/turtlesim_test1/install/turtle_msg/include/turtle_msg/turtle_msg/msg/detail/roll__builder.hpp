// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from turtle_msg:msg/Roll.idl
// generated code does not contain a copyright notice

#ifndef TURTLE_MSG__MSG__DETAIL__ROLL__BUILDER_HPP_
#define TURTLE_MSG__MSG__DETAIL__ROLL__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "turtle_msg/msg/detail/roll__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace turtle_msg
{

namespace msg
{

namespace builder
{

class Init_Roll_z1
{
public:
  explicit Init_Roll_z1(::turtle_msg::msg::Roll & msg)
  : msg_(msg)
  {}
  ::turtle_msg::msg::Roll z1(::turtle_msg::msg::Roll::_z1_type arg)
  {
    msg_.z1 = std::move(arg);
    return std::move(msg_);
  }

private:
  ::turtle_msg::msg::Roll msg_;
};

class Init_Roll_y1
{
public:
  explicit Init_Roll_y1(::turtle_msg::msg::Roll & msg)
  : msg_(msg)
  {}
  Init_Roll_z1 y1(::turtle_msg::msg::Roll::_y1_type arg)
  {
    msg_.y1 = std::move(arg);
    return Init_Roll_z1(msg_);
  }

private:
  ::turtle_msg::msg::Roll msg_;
};

class Init_Roll_x1
{
public:
  Init_Roll_x1()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Roll_y1 x1(::turtle_msg::msg::Roll::_x1_type arg)
  {
    msg_.x1 = std::move(arg);
    return Init_Roll_y1(msg_);
  }

private:
  ::turtle_msg::msg::Roll msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::turtle_msg::msg::Roll>()
{
  return turtle_msg::msg::builder::Init_Roll_x1();
}

}  // namespace turtle_msg

#endif  // TURTLE_MSG__MSG__DETAIL__ROLL__BUILDER_HPP_
