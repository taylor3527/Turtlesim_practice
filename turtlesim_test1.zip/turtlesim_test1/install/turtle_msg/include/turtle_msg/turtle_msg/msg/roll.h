// generated from rosidl_generator_c/resource/idl.h.em
// with input from turtle_msg:msg/Roll.idl
// generated code does not contain a copyright notice

#ifndef TURTLE_MSG__MSG__ROLL_H_
#define TURTLE_MSG__MSG__ROLL_H_

#include "turtle_msg/msg/detail/roll__struct.h"
#include "turtle_msg/msg/detail/roll__functions.h"
#include "turtle_msg/msg/detail/roll__type_support.h"

#endif  // TURTLE_MSG__MSG__ROLL_H_
