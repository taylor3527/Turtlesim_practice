// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from turtle_msg:msg/Linear.idl
// generated code does not contain a copyright notice

#ifndef TURTLE_MSG__MSG__DETAIL__LINEAR__BUILDER_HPP_
#define TURTLE_MSG__MSG__DETAIL__LINEAR__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "turtle_msg/msg/detail/linear__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace turtle_msg
{

namespace msg
{

namespace builder
{

class Init_Linear_lz
{
public:
  explicit Init_Linear_lz(::turtle_msg::msg::Linear & msg)
  : msg_(msg)
  {}
  ::turtle_msg::msg::Linear lz(::turtle_msg::msg::Linear::_lz_type arg)
  {
    msg_.lz = std::move(arg);
    return std::move(msg_);
  }

private:
  ::turtle_msg::msg::Linear msg_;
};

class Init_Linear_ly
{
public:
  explicit Init_Linear_ly(::turtle_msg::msg::Linear & msg)
  : msg_(msg)
  {}
  Init_Linear_lz ly(::turtle_msg::msg::Linear::_ly_type arg)
  {
    msg_.ly = std::move(arg);
    return Init_Linear_lz(msg_);
  }

private:
  ::turtle_msg::msg::Linear msg_;
};

class Init_Linear_lx
{
public:
  Init_Linear_lx()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Linear_ly lx(::turtle_msg::msg::Linear::_lx_type arg)
  {
    msg_.lx = std::move(arg);
    return Init_Linear_ly(msg_);
  }

private:
  ::turtle_msg::msg::Linear msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::turtle_msg::msg::Linear>()
{
  return turtle_msg::msg::builder::Init_Linear_lx();
}

}  // namespace turtle_msg

#endif  // TURTLE_MSG__MSG__DETAIL__LINEAR__BUILDER_HPP_
