// generated from rosidl_generator_c/resource/idl.h.em
// with input from turtle_msg:msg/Direction.idl
// generated code does not contain a copyright notice

#ifndef TURTLE_MSG__MSG__DIRECTION_H_
#define TURTLE_MSG__MSG__DIRECTION_H_

#include "turtle_msg/msg/detail/direction__struct.h"
#include "turtle_msg/msg/detail/direction__functions.h"
#include "turtle_msg/msg/detail/direction__type_support.h"

#endif  // TURTLE_MSG__MSG__DIRECTION_H_
