// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef TURTLE_MSG__MSG__LINEAR_HPP_
#define TURTLE_MSG__MSG__LINEAR_HPP_

#include "turtle_msg/msg/detail/linear__struct.hpp"
#include "turtle_msg/msg/detail/linear__builder.hpp"
#include "turtle_msg/msg/detail/linear__traits.hpp"

#endif  // TURTLE_MSG__MSG__LINEAR_HPP_
