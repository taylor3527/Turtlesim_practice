// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef TURTLE_MSG__MSG__DIRECTION_HPP_
#define TURTLE_MSG__MSG__DIRECTION_HPP_

#include "turtle_msg/msg/detail/direction__struct.hpp"
#include "turtle_msg/msg/detail/direction__builder.hpp"
#include "turtle_msg/msg/detail/direction__traits.hpp"

#endif  // TURTLE_MSG__MSG__DIRECTION_HPP_
