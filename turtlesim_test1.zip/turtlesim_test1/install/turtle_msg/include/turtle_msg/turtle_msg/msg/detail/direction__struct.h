// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from turtle_msg:msg/Direction.idl
// generated code does not contain a copyright notice

#ifndef TURTLE_MSG__MSG__DETAIL__DIRECTION__STRUCT_H_
#define TURTLE_MSG__MSG__DETAIL__DIRECTION__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in msg/Direction in the package turtle_msg.
typedef struct turtle_msg__msg__Direction
{
  int64_t dir;
} turtle_msg__msg__Direction;

// Struct for a sequence of turtle_msg__msg__Direction.
typedef struct turtle_msg__msg__Direction__Sequence
{
  turtle_msg__msg__Direction * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} turtle_msg__msg__Direction__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // TURTLE_MSG__MSG__DETAIL__DIRECTION__STRUCT_H_
