// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from turtle_msg:msg/Roll.idl
// generated code does not contain a copyright notice

#ifndef TURTLE_MSG__MSG__DETAIL__ROLL__STRUCT_H_
#define TURTLE_MSG__MSG__DETAIL__ROLL__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in msg/Roll in the package turtle_msg.
typedef struct turtle_msg__msg__Roll
{
  double x1;
  double y1;
  double z1;
} turtle_msg__msg__Roll;

// Struct for a sequence of turtle_msg__msg__Roll.
typedef struct turtle_msg__msg__Roll__Sequence
{
  turtle_msg__msg__Roll * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} turtle_msg__msg__Roll__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // TURTLE_MSG__MSG__DETAIL__ROLL__STRUCT_H_
