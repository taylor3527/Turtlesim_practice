// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from turtle_msg:msg/Linear.idl
// generated code does not contain a copyright notice

#ifndef TURTLE_MSG__MSG__DETAIL__LINEAR__TRAITS_HPP_
#define TURTLE_MSG__MSG__DETAIL__LINEAR__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "turtle_msg/msg/detail/linear__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace turtle_msg
{

namespace msg
{

inline void to_flow_style_yaml(
  const Linear & msg,
  std::ostream & out)
{
  out << "{";
  // member: lx
  {
    out << "lx: ";
    rosidl_generator_traits::value_to_yaml(msg.lx, out);
    out << ", ";
  }

  // member: ly
  {
    out << "ly: ";
    rosidl_generator_traits::value_to_yaml(msg.ly, out);
    out << ", ";
  }

  // member: lz
  {
    out << "lz: ";
    rosidl_generator_traits::value_to_yaml(msg.lz, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const Linear & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: lx
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "lx: ";
    rosidl_generator_traits::value_to_yaml(msg.lx, out);
    out << "\n";
  }

  // member: ly
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "ly: ";
    rosidl_generator_traits::value_to_yaml(msg.ly, out);
    out << "\n";
  }

  // member: lz
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "lz: ";
    rosidl_generator_traits::value_to_yaml(msg.lz, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const Linear & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace turtle_msg

namespace rosidl_generator_traits
{

[[deprecated("use turtle_msg::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const turtle_msg::msg::Linear & msg,
  std::ostream & out, size_t indentation = 0)
{
  turtle_msg::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use turtle_msg::msg::to_yaml() instead")]]
inline std::string to_yaml(const turtle_msg::msg::Linear & msg)
{
  return turtle_msg::msg::to_yaml(msg);
}

template<>
inline const char * data_type<turtle_msg::msg::Linear>()
{
  return "turtle_msg::msg::Linear";
}

template<>
inline const char * name<turtle_msg::msg::Linear>()
{
  return "turtle_msg/msg/Linear";
}

template<>
struct has_fixed_size<turtle_msg::msg::Linear>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<turtle_msg::msg::Linear>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<turtle_msg::msg::Linear>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // TURTLE_MSG__MSG__DETAIL__LINEAR__TRAITS_HPP_
