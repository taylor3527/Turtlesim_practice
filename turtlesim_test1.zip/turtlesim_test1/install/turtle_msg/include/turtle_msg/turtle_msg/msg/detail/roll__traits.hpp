// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from turtle_msg:msg/Roll.idl
// generated code does not contain a copyright notice

#ifndef TURTLE_MSG__MSG__DETAIL__ROLL__TRAITS_HPP_
#define TURTLE_MSG__MSG__DETAIL__ROLL__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "turtle_msg/msg/detail/roll__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace turtle_msg
{

namespace msg
{

inline void to_flow_style_yaml(
  const Roll & msg,
  std::ostream & out)
{
  out << "{";
  // member: x1
  {
    out << "x1: ";
    rosidl_generator_traits::value_to_yaml(msg.x1, out);
    out << ", ";
  }

  // member: y1
  {
    out << "y1: ";
    rosidl_generator_traits::value_to_yaml(msg.y1, out);
    out << ", ";
  }

  // member: z1
  {
    out << "z1: ";
    rosidl_generator_traits::value_to_yaml(msg.z1, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const Roll & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: x1
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "x1: ";
    rosidl_generator_traits::value_to_yaml(msg.x1, out);
    out << "\n";
  }

  // member: y1
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "y1: ";
    rosidl_generator_traits::value_to_yaml(msg.y1, out);
    out << "\n";
  }

  // member: z1
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "z1: ";
    rosidl_generator_traits::value_to_yaml(msg.z1, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const Roll & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace turtle_msg

namespace rosidl_generator_traits
{

[[deprecated("use turtle_msg::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const turtle_msg::msg::Roll & msg,
  std::ostream & out, size_t indentation = 0)
{
  turtle_msg::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use turtle_msg::msg::to_yaml() instead")]]
inline std::string to_yaml(const turtle_msg::msg::Roll & msg)
{
  return turtle_msg::msg::to_yaml(msg);
}

template<>
inline const char * data_type<turtle_msg::msg::Roll>()
{
  return "turtle_msg::msg::Roll";
}

template<>
inline const char * name<turtle_msg::msg::Roll>()
{
  return "turtle_msg/msg/Roll";
}

template<>
struct has_fixed_size<turtle_msg::msg::Roll>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<turtle_msg::msg::Roll>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<turtle_msg::msg::Roll>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // TURTLE_MSG__MSG__DETAIL__ROLL__TRAITS_HPP_
